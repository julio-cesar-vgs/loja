import java.awt.RenderingHints;
import java.awt.Transparency;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.ParameterBlock;
import java.awt.image.renderable.RenderableImage;

import javax.media.jai.IHSColorSpace;
import javax.media.jai.ImageLayout;
import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import javax.swing.JFrame;

public class ManipulandoUmaIMagem {
	public static void main(String[] args) {
		PlanarImage imagem = JAI.create("fileload", args[0]);
		IHSColorSpace ihs = IHSColorSpace.getInstance();
		ColorModel modeloIHS = new ComponentColorModel(ihs, new int[] { 8, 8, 8 }, false, false, Transparency.OPAQUE,
				DataBuffer.TYPE_BYTE);
		ParameterBlock pb = new ParameterBlock();
		pb.addSource(imagem);
		pb.add(modeloIHS);
		RenderableImage imagemIHS = (RenderableImage) JAI.create("colorconvert", pb);
		RenderedImage[] bandas = new RenderedImage[3];
		for (int band = 0; band < 3; band++) {
			pb = new ParameterBlock();
			pb.addSource(imagemIHS);
			pb.add(new int[] { band });
			bandas[band] = JAI.create("bandSelect", pb);
		}

		RenderedImage novaIntensidade = JAI.create("constant", pb);
		pb = new ParameterBlock();
		pb.add((float) imagem.getWidth());
		pb.add((float) imagem.getHeight());
		pb.add(new Byte[] { (byte) 255 });

		RenderedImage novaSaturacao = JAI.create("constant", pb);
		pb = new ParameterBlock();
		pb.add((float) imagem.getWidth());
		pb.add((float) imagem.getHeight());
		pb.add(new Byte[] { (byte) 255 });

		ImageLayout imageLayout = new ImageLayout();

		imageLayout.setColorModel(modeloIHS);
		imageLayout.setSampleModel(imageLayout.getSampleModel(novaSaturacao));
		RenderingHints rendHinsts = new RenderingHints(JAI.KEY_IMAGE_LAYOUT, imageLayout);
		pb = new ParameterBlock();
		pb.addSource(novaIntensidade);
		pb.addSource(bandas[1]);
		pb.addSource(novaSaturacao);

		RenderedImage imagemIHSModificada = JAI.create("bandmerge", pb, rendHinsts);

		pb = new ParameterBlock();
		pb.addSource(imagemIHSModificada);
		pb.add(imageLayout.getColorModel(imagemIHSModificada));
		RenderedImage imagemFinal = JAI.create("colorconvert", pb);

		JFrame frame = new JFrame("Modifi��o via IHS");
		frame.add(new DisplayTwoSynchronizedImages(imagem, imagemFinal));
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
}
