import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import javax.swing.JFrame;

public class InvertendoImagem {
	public static void main(String[] args) {
		PlanarImage input = JAI.create("fileload", args[0]);
		PlanarImage output = JAI.create("fileload", input);
		
		JFrame frame = new JFrame();
		frame.setTitle("Invert Image" + args[0]);
		frame.getContentPane().add(new DisplayTwoSynchronizedImages(input, output));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		
	}
}
