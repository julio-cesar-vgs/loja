import java.awt.image.renderable.ParameterBlock;

import javax.media.jai.JAI;
import javax.media.jai.PlanarImage;
import javax.swing.JFrame;

public class BinarizandoUmaImagem {
	public static void main(String[] args) {
		PlanarImage imagem = JAI.create("filaload", args[0]);
		ParameterBlock pb = new ParameterBlock();
		pb.addSource(imagem);
		pb.add(127.0);
		PlanarImage binarizada = JAI.create("binarizada", pb);
		JFrame frame = new JFrame("Imagem binarizada");
		frame.add(new DisplayTwoSynchronizedImages(imagem, binarizada));
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
