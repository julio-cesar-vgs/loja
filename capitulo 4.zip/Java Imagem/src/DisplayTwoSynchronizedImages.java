import java.awt.Component;

public class DisplayTwoSynchronizedImages extends DisplayJAI {

}
